/*
* Author: Christian Huitema
* Copyright (c) 2020, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <stdlib.h>
#include <string.h>

#include "picoquic.h"
#include "picoquic_internal.h"
#include "picoquic_utils.h"
#include "picoquic_config.h"
#include "picoquictest_internal.h"
#include "picoquic_newreno.h"
#include "picoquic_cubic.h"
#include "picoquic_bbr.h"
#include "picoqmux.h"

#ifdef PICOQUIC_WITHOUT_SSLKEYLOG
static char* ref_option_text = "c:k:p:v:o:w:x:rR:s:XS:G:H:P:O:Me:C:i:l:Lb:q:m:n:a:t:zI:d:DQT:N:B:F:VU:0j:W:J:E:y:K:Z:4:6:Y:h";
#else
static char* ref_option_text = "c:k:p:v:o:w:x:rR:s:XS:G:H:P:O:Me:C:i:l:Lb:q:m:n:a:t:zI:d:DQT:N:B:F:VU:0j:W:8J:E:y:K:Z:4:6:Y:h";
#endif
int config_option_letters_test(void)
{
    char option_text[256];
    int ret = picoquic_config_option_letters(option_text, sizeof(option_text), NULL);

    if (ret != 0) {
        DBG_PRINTF("picoquic_config_option_letters returns %d", ret);
    }
    else if (strcmp(option_text, ref_option_text) != 0) {
        DBG_PRINTF("picoquic_config_option_letters returns %s", option_text);
        ret = -1;
    }

    return ret;
}

const uint8_t null_key[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

#define ECH_TEST_CONFIG "AGT+DQBgAgAQAEEE2silQFS6M9oYqUF/SVPfYOamPbaOUzqf3RkUXqsDz7z7NpgWJI8HKW0V2E8w6Alk+xT8hnzUBsL9neiZP0iMKwAEAAEAAf8QdGVzdC5leGFtcGxlLmNvbQAA"

const uint8_t ech_test_config_bin[102] = {
0x00, 0x64, 0xfe, 0x0d, 0x00, 0x60, 0x02, 0x00, 0x10, 0x00, 0x41, 0x04, 0xda, 0xc8, 0xa5, 0x40,
0x54, 0xba, 0x33, 0xda, 0x18, 0xa9, 0x41, 0x7f, 0x49, 0x53, 0xdf, 0x60, 0xe6, 0xa6, 0x3d, 0xb6,
0x8e, 0x53, 0x3a, 0x9f, 0xdd, 0x19, 0x14, 0x5e, 0xab, 0x03, 0xcf, 0xbc, 0xfb, 0x36, 0x98, 0x16,
0x24, 0x8f, 0x07, 0x29, 0x6d, 0x15, 0xd8, 0x4f, 0x30, 0xe8, 0x09, 0x64, 0xfb, 0x14, 0xfc, 0x86,
0x7c, 0xd4, 0x06, 0xc2, 0xfd, 0x9d, 0xe8, 0x99, 0x3f, 0x48, 0x8c, 0x2b, 0x00, 0x04, 0x00, 0x01,
0x00, 0x01, 0xff, 0x10, 0x74, 0x65, 0x73, 0x74, 0x2e, 0x65, 0x78, 0x61, 0x6d, 0x70, 0x6c, 0x65,
0x2e, 0x63, 0x6f, 0x6d, 0x00, 0x00 };


static picoquic_quic_config_t param1 = {
    1024, /*uint32_t nb_connections; */
    "/data/github/picoquic", /* char const* solution_dir; */
    "/data/certs/cert.pem", /* char const* server_cert_file; */
    "/data/certs/key.pem", /* char const* server_key_file; */
    "/data/log.txt", /* char const* log_file; */
    "/data/log/", /* char const* bin_dir; */
    "/data/qlog/", /* char const* qlog_dir; */
    "/data/performance_log.csv", /* char const* performance_log; */
    4433, /* int server_port; */
    12345, /* int local_port; */
    1, /* int is_port_shared; */
    0, /* int nb_threads; */
    1, /* int dest_if; */
    1536, /* int mtu_max; */
    -1, /* int cnx_id_length; */
    PICOQUIC_MICROSEC_HANDSHAKE_MAX/1000, /* int idle_timeout */
    655360, /* Socket buffer size */
    "bbr", /* const picoquic_congestion_algorithm_t* cc_algorithm; */
    "T250000", /* BBR option */
    "0N8C-000123", /* char const* cnx_id_cbdata; */
    3, /* spin bit policy */
    2, /* loss bit policy */
    1, /* multipath option */
    "127.0.0.1",
    1,
    UINT64_MAX, /* Do not limit CWIN */
    3, /* Address discovery mode = 3 (cli param -J 2)*/
    /* Common flags */
    1, /* unsigned int initial_random : 1; */
    1, /* unsigned int use_long_log : 1; */
    1, /* unsigned int do_preemptive_repeat : 1; */
    1, /* unsigned int do_not_use_gso : 1 */
    0, /* disable port blocking */
#ifndef PICOQUIC_WITHOUT_SSLKEYLOG
    0,
#endif
    /* Server only */
    "/data/www/", /* char const* www_dir; */
    { 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef,
      0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10}, /* uint8_t reset_seed[16]; */
    null_key, /* const uint8_t* ticket_encryption_key; */
    0, /* size_t ticket_encryption_key_length; */
    /* Server flags */
    1, /* unsigned int do_retry : 1; */
    1, /* unsigned int has_reset_seed : 1;*/
    /* Client only */
    NULL, /* char const* ticket_file_name; */
    NULL, /* char const* token_file_name; */
    NULL, /* char const* sni; */
    NULL, /* char const* alpn; */
    NULL, /* char const* out_dir; */
    NULL, /* char const* root_trust_file; */
    0, /* int cipher_suite_id; */
    0, /* uint32_t proposed_version; */
    0, /* uint32_t desired_version; */
    0, /* unsigned int force_zero_share : 1; */
    0, /* unsigned int no_disk : 1; */
    0, /* unsigned int large_client_hello : 1; */
    "ech_key.pem",
    "ech_config.pem",
    "test.example.com",
    NULL, /* ech_target */
    0, /* ech_target_len */
    1000001, /* flow_control_max */
    "192.0.2.1", /* Preferred Address V4 */
    "2001:db8::1", /* Preferred Address V6 */
    "443:17" /* QMux port and number of connections */
};

static char const* config_argv1[] = {
    "-S", "/data/github/picoquic",
    "-c", "/data/certs/cert.pem",
    "-k", "/data/certs/key.pem",
    "-x", "1024",
    "-l", "/data/log.txt",
    "-b", "/data/log/",
    "-q", "/data/qlog/",
    "-p", "4433",
    "-e", "1",
    "-m", "1536",
    "-G", "bbr",
    "-H", "T250000",
    "-P", "3",
    "-O", "2",
    "-M",
    "-R", "1",
    "-L",
    "-w", "/data/www/",
    "-r",
    "-s", "0123456789abcdeffedcba9876543210",
    "-B", "655360",
    "-F", "/data/performance_log.csv",
    "-V",
    "-j", "1",
    "-0",
    "-i", "0N8C-000123",
    "-J", "2",
    "-E", "ech_key.pem", "ech_config.pem",
    "-y", "test.example.com",
    "-Z", "1000001",
    "-4", "192.0.2.1",
    "-6", "2001:db8::1",
    "-Y", "443",
    NULL
};

static picoquic_quic_config_t param2 = {
    256, /*uint32_t nb_connections; */
    NULL, /* char const* solution_dir; */
    NULL, /* char const* server_cert_file; */
    NULL, /* char const* server_key_file; */
    NULL, /* char const* log_file; */
    NULL, /* char const* bin_dir; */
    NULL, /* char const* qlog_dir; */
    NULL, /* char const* performance_log; */
    0, /* int server_port; */
    0, /* int local_port; */
    0, /* int is_port_shared; */
    0, /* int nb_threads; */
    0, /* int dest_if; */
    0, /* int mtu_max; */
    5, /* int cnx_id_length; */
    1234567, /* int idle_timeout */
    0, /* socket_buffer_size */
    NULL, /* const picoquic_congestion_algorithm_t* cc_algorithm; */
    NULL, /* option string */
    NULL, /* char const* cnx_id_cbdata; */
    0, /* spin bit policy */
    0, /* loss bit policy */
    0, /* multipath option */
    "127.0.0.1",
    0,
    1000000, /* Limit CWIN to 1 million bytes */
    0, /* Do not enable address discovery */
    /* Common flags */
    3, /* unsigned int initial_random : 1; */
    0, /* unsigned int use_long_log : 1; */
    0, /* unsigned int do_preemptive_repeat : 1; */
    0, /* unsigned int do_not_use_gso : 1 */
    1, /* disable port blocking */
#ifndef PICOQUIC_WITHOUT_SSLKEYLOG
    1,
#endif
    /* Server only */
    NULL, /* char const* www_dir; */
    { 0 }, /* Reset seed */
    NULL, /* const uint8_t* ticket_encryption_key; */
    0, /* size_t ticket_encryption_key_length; */
    /* Server flags */
    0, /* unsigned int do_retry : 1; */
    0, /* unsigned int  has reset seed : 1; */
    /* Client only */
    "/data/tickets.bin", /* char const* ticket_file_name; */
    "/data/tokens.bin", /* char const* token_file_name; */
    "test.example.com", /* char const* sni; */
    "test", /* char const* alpn; */
    "/data/w_out", /* char const* out_dir; */
    "data/certs/root.pem", /* char const* root_trust_file; */
    20, /* int cipher_suite_id; */
    0xff000020, /* uint32_t proposed_version; */
    0x00000002, /* uint32_t desired_version; */
    1,/* unsigned int force_zero_share : 1; */
    1, /* unsigned int no_disk : 1; */
    1, /* unsigned int large_client_hello : 1; */
    NULL,
    NULL,
    NULL, /* ECH public name */
    (uint8_t *)ech_test_config_bin, /* ech_target */
    sizeof(ech_test_config_bin), /* ech_target_len */
    0, /* flow control max */
    NULL,
    NULL,
    NULL
};

static const char* config_argv2[] = {
    "-n", "test.example.com",
    "-a", "test",
    "-o", "/data/w_out",
    "-t", "data/certs/root.pem",
    "-C", "20",
    "-v", "fF000020",
    "-z",
    "-d", "1234567",
    "-D",
    "-Q",
    "-X",
#ifndef PICOQUIC_WITHOUT_SSLKEYLOG
    "-8",
#endif
    "-I", "5",
    "-T", "/data/tickets.bin",
    "-N", "/data/tokens.bin",
    "-U", "00000002",
    "-W", "1000000",
    "-K", ECH_TEST_CONFIG,
    "-Z", "0",
    NULL
};

static const char * config_two[] = {
    "--sni", "test.example.com",
    "--alpn", "test",
    "--outdir", "/data/w_out",
    "--root_trust_file", "data/certs/root.pem",
    "--cipher_suite", "20",
    "--proposed_version", "ff000020",
    "--force_zero_share",
    "--idle_timeout", "1234567",
    "--no_disk",
    "--large_client_hello",
    "--disable_block",
#ifndef PICOQUIC_WITHOUT_SSLKEYLOG
    "--sslkeylog",
#endif
    "--cnxid_length", "5",
    "--ticket_file", "/data/tickets.bin",
    "--token_file", "/data/tokens.bin",
    "--version_upgrade", "00000002",
    "--cwin_max", "1000000",
    "--ech_c", ECH_TEST_CONFIG,
    "--flow_control_max", "0",
    NULL
};

typedef struct st_config_error_test_t {
    int nb_args;
    char const* err_args[2];
} config_error_test_t;

static config_error_test_t config_errors[] = {
    { 1, { "-A"}},
    { 1, { "-S" }},
    { 1, { "-c"}},
    { 1, { "-k"}},
    { 1, { "-x"}},
    { 2, { "-x", "nb_cnx"}},
    { 1, { "-l"}},
    { 1, { "-b"}},
    { 1, { "-q"}},
    { 2, { "-p", "port"}},
    { 1, { "-p" }},
    { 1, { "-e", }},
    { 2, { "-e", "a" }},
    { 1, { "-m" }},
    { 1, { "-m", "-1"}},
    { 2, { "-m", "15360"}},
    { 2, { "-P", "33"}},
    { 2, { "-O", "22"}},
    { 2, { "-R", "17"}},
    { 1, { "-w" }},
    { 2, { "-s", "0123456789abcdexyedcba9876543210"}},
    { 2, { "-s", "0123456789abcdeffedcba987654321"}},
    { 2, { "-s", "0123456789abcdeffedcba98765432"}},
    { 2, { "-B", "buffer"}},
    { 1, { "-F" }},
    { 2, { "-j", "3" }},
    { 1, { "-i" }},
    { 2, { "-I", "-1" }},
    { 2, { "-I", "255" }},
    { 2, { "-U", "XY000002" }},
    { 2, { "-W", "cwin" }},
    { 2, { "-d", "idle" }},
    { 1, { "-Z" }},
    { 2, { "-Z", "0123456789abcdexyedcba9876543210" }},
#ifdef PICOQUIC_WITHOUT_SSLKEYLOG
    { 1, {"-8"}},
#endif
};

static size_t nb_config_errors = sizeof(config_errors) / sizeof(config_error_test_t);


/* Register a small and stable list of congestion control algorithms,
* sufficient to test the cc algorithm configuration functions.
 */

static picoquic_congestion_algorithm_t const* config_test_cc_algo_list[3] = {
    NULL, NULL, NULL
};

static void config_test_register_cc_algorithms(void)
{
    config_test_cc_algo_list[0] = picoquic_newreno_algorithm;
    config_test_cc_algo_list[1] = picoquic_cubic_algorithm;
    config_test_cc_algo_list[2] = picoquic_bbr_algorithm;
    picoquic_register_congestion_control_algorithms(config_test_cc_algo_list, 3);
}

int config_test_compare_string(const char* title, const char* expected, const char* actual)
{
    int ret = 0;

    if (expected == NULL) {
        if (actual != NULL) {
            DBG_PRINTF("Expected %s = NULL, got %x", title, actual);
            ret = -1;
        }
    }
    else if (actual == NULL) {
        DBG_PRINTF("Expected %s = %s, got NULL", title, expected);
        ret = -1;
    }
    else if (strcmp(expected, actual) != 0) {
        DBG_PRINTF("Expected %s = %s, got %s", title, actual, expected);
        ret = -1;
    }
    return ret;
}

int config_test_compare_int(const char* title, int expected, int actual)
{
    int ret = 0;
    
    if (expected != actual) {
        DBG_PRINTF("Expected %s = %d, got %d", title, actual, expected);
        ret = -1;
    }
    return ret;
}

int config_test_compare_uint64(const char* title, uint64_t expected, uint64_t actual)
{
    int ret = 0;

    if (expected != actual) {
        DBG_PRINTF("Expected %s = %" PRIu64 ", got %" PRIu64, title, actual, expected);
        ret = -1;
    }
    return ret;
}

int config_test_compare_uint32(const char* title, uint32_t expected, uint32_t actual)
{
    int ret = 0;

    if (expected != actual) {
        DBG_PRINTF("Expected %s = 0x%" PRIx32 ", got 0x%" PRIx32, title, actual, expected);
        ret = -1;
    }
    return ret;
}

int config_test_compare(const picoquic_quic_config_t* expected, const picoquic_quic_config_t* actual)
{
    int ret = 0;

    ret |= config_test_compare_int("nb_connections", expected->nb_connections, actual->nb_connections);
    ret |= config_test_compare_string("solution_dir", expected->solution_dir, actual->solution_dir);
    ret |= config_test_compare_string("server_cert_file", expected->server_cert_file, actual->server_cert_file);
    ret |= config_test_compare_string("server_key_file", expected->server_key_file, actual->server_key_file);
    ret |= config_test_compare_string("log_file", expected->log_file, actual->log_file);
    ret |= config_test_compare_string("bin_dir", expected->bin_dir, actual->bin_dir);
    ret |= config_test_compare_string("qlog_dir", expected->qlog_dir, actual->qlog_dir);
    ret |= config_test_compare_string("performance_log", expected->performance_log, actual->performance_log);
    ret |= config_test_compare_int("port", expected->server_port, actual->server_port);
    ret |= config_test_compare_int("dest_if", expected->dest_if, actual->dest_if);
    ret |= config_test_compare_int("mtu_max", expected->mtu_max, actual->mtu_max);
    ret |= config_test_compare_int("socket_buffer_size", expected->socket_buffer_size, actual->socket_buffer_size);
    ret |= config_test_compare_string("cc_algo_id", expected->cc_algo_id, actual->cc_algo_id);
    ret |= config_test_compare_string("cnx_id_cbdata", expected->cnx_id_cbdata, actual->cnx_id_cbdata);
    ret |= config_test_compare_int("spinbit", expected->spinbit_policy, actual->spinbit_policy);
    ret |= config_test_compare_int("lossbit", expected->lossbit_policy, actual->lossbit_policy);
    ret |= config_test_compare_int("multipath", expected->multipath_option, actual->multipath_option);
    ret |= config_test_compare_int("initial_random", expected->initial_random, actual->initial_random);
    ret |= config_test_compare_int("use_long_log", expected->use_long_log, actual->use_long_log);
    ret |= config_test_compare_int("preemptive_repeat", expected->do_preemptive_repeat, actual->do_preemptive_repeat);
    ret |= config_test_compare_int("no_gso", expected->do_not_use_gso, actual->do_not_use_gso);
    ret |= config_test_compare_string("www_dir", expected->www_dir, actual->www_dir);
    ret |= config_test_compare_int("do_retry", expected->do_retry, actual->do_retry);
    /* TODO: reset_seed */
    ret |= config_test_compare_string("sni", expected->sni, actual->sni);
    ret |= config_test_compare_string("alpn", expected->alpn, actual->alpn);
    ret |= config_test_compare_string("out_dir", expected->out_dir, actual->out_dir);
    ret |= config_test_compare_string("root_trust_file", expected->root_trust_file, actual->root_trust_file);
    ret |= config_test_compare_string("root_trust_file", expected->root_trust_file, actual->root_trust_file);
    ret |= config_test_compare_int("cipher_suite_id", expected->cipher_suite_id, actual->cipher_suite_id);
    ret |= config_test_compare_uint32("proposed_version", expected->proposed_version, actual->proposed_version);
    ret |= config_test_compare_uint32("desired_version", expected->desired_version, actual->desired_version);
    ret |= config_test_compare_int("force_zero_share", expected->force_zero_share, actual->force_zero_share);
    ret |= config_test_compare_int("no_disk", expected->no_disk, actual->no_disk);
    ret |= config_test_compare_int("large_client_hello", expected->large_client_hello, actual->large_client_hello);
    ret |= config_test_compare_int("cnx_id_length", expected->cnx_id_length, actual->cnx_id_length);
    ret |= config_test_compare_int("bdp", expected->bdp_frame_option, actual->bdp_frame_option);
    ret |= config_test_compare_int("idle_timeout", expected->idle_timeout, actual->idle_timeout);
    ret |= config_test_compare_uint64("cwin_max", expected->cwin_max, actual->cwin_max);
#ifndef PICOQUIC_WITHOUT_SSLKEYLOG
    ret |= config_test_compare_int("sslkeylog", expected->enable_sslkeylog, actual->enable_sslkeylog);
#endif
    ret |= config_test_compare_string("ech_key_file", expected->ech_key_file, actual->ech_key_file);
    ret |= config_test_compare_string("ech_config_file", expected->ech_config_file, actual->ech_config_file);
    ret |= config_test_compare_string("ech_public_name", expected->ech_public_name, actual->ech_public_name);
    ret |= config_test_compare_uint64("flow_control_max", expected->flow_control_max, actual->flow_control_max);
    ret |= config_test_compare_string("preferred_address_v4", expected->preferred_address_v4, actual->preferred_address_v4);
    ret |= config_test_compare_string("preferred_address_v6", expected->preferred_address_v6, actual->preferred_address_v6);
    if (expected->ech_target == NULL) {
        if (actual->ech_target != NULL || actual->ech_target_len != 0) {
            ret = -1;
        }
    }
    else {
        if (actual->ech_target == NULL ||
            actual->ech_target_len != expected->ech_target_len ||
            memcmp(actual->ech_target, expected->ech_target, expected->ech_target_len) != 0) {
            ret = -1;
        }
    }
    
    return ret;
}

static int config_parse_command_line(picoquic_quic_config_t* actual, const char** argv, int argc, int expect_error)
{
    int ret = 0;
    int opt_ind = 0;

    picoquic_config_init(actual);

    while (opt_ind < argc && ret == 0) {
        const char* x = argv[opt_ind];
        const char* optval = NULL;
        int opt;
        if (x == NULL) {
            /* could not parse to the end! */
            if (!expect_error) {
                DBG_PRINTF("Unexpected stop after %d arguments, expected %d", opt_ind, argc);
            }
            ret = -1;
            break;
        }
        else if (x[0] != '-' || x[1] == 0 || x[2] != 0) {
            /* Either next argument, or single "-", or more than one char ! */
            if (!expect_error) {
                DBG_PRINTF("Unexpected argument: %s", x);
            }
            ret = -1;
            break;
        }

        opt = x[1];
        opt_ind++;
        if (opt_ind < argc) {
            optval = argv[opt_ind];
            if (optval[0] == '-') {
                optval = NULL;
            }
            else {
                opt_ind++;
            }
        }

        ret = picoquic_config_command_line(opt, &opt_ind, argc, argv, optval, actual);
        if (ret != 0) {
            if (!expect_error) {
                DBG_PRINTF("Could not parse opt -%c", opt);
            }
        }
    }

    return (ret);
}


static int config_parse_command_line_test(const picoquic_quic_config_t* expected, const char** argv, int argc)
{
    int ret = 0;
    picoquic_quic_config_t actual;

    ret = config_parse_command_line(&actual, argv, argc, 0);

    if (ret == 0) {
        ret = config_test_compare(expected, &actual);
    }

    picoquic_config_clear(&actual);

    return (ret);
}

int config_test_parse_command_line_ex(const picoquic_quic_config_t* expected, const char** argv, int argc)
{
    int ret = 0;
    int opt_ind = 0;
    picoquic_quic_config_t actual;

    picoquic_config_init(&actual);

    while (opt_ind < argc && ret == 0) {
        const char* x = argv[opt_ind];
        const char* optval = NULL;

        if (x == NULL) {
            /* could not parse to the end! */
            DBG_PRINTF("Unexpected stop after %d arguments, expected %d", opt_ind, argc);
            ret = -1;
            break;
        }
        else if (x[0] != '-' || x[1] == 0 || 
            (x[2] != 0 && x[1] != '-')) {
            /* could not parse to the end! */
            DBG_PRINTF("Unexpected argument: %s", x);
            ret = -1;
            break;
        }
        opt_ind++;
        if (opt_ind < argc) {
            optval = argv[opt_ind];
            if (optval[0] == '-') {
                optval = NULL;
            }
            else {
                opt_ind++;
            }
        }
        ret = picoquic_config_command_line_ex(x, &opt_ind, argc, argv, optval, &actual);
        if (ret != 0) {
            DBG_PRINTF("Could not parse opt %s", x);
        }
    }

    if (ret == 0) {
        ret = config_test_compare(expected, &actual);
    }

    picoquic_config_clear(&actual);
  
    return (ret);
}

int config_set_option_test_one(void)
{
    int ret = 0;
    char const* ticket_store = "ticket_store.bin";
    char const* token_store = "ticket_store.bin";

    picoquic_quic_config_t config = { 0 };
    if (ret == 0 && config.ticket_file_name == NULL) {
        ret = picoquic_config_set_option(&config, picoquic_option_Ticket_File_Name, ticket_store);
    }
    if (ret == 0 && config.token_file_name == NULL) {
        ret = picoquic_config_set_option(&config, picoquic_option_Token_File_Name, token_store);
    }
    if (ret == 0 &&
        (config.ticket_file_name == NULL || strcmp(config.ticket_file_name, ticket_store) != 0)) {
        ret = -1;
    }
    if (ret == 0 &&
        (config.token_file_name == NULL || strcmp(config.token_file_name, token_store) != 0)) {
        ret = -1;
    }
    picoquic_config_clear(&config);

    return (ret);
}

int config_option_test(void)
{
    int ret = config_parse_command_line_test(&param1, config_argv1, (int)(sizeof(config_argv1) / sizeof(char const*)) - 1);
    if (ret != 0) {
        DBG_PRINTF("First config option test returns %d", ret);
    }
    if (ret == 0) {
        ret = config_parse_command_line_test(&param2, config_argv2, (int)(sizeof(config_argv2) / sizeof(char const*)) - 1);

        if (ret != 0) {
            DBG_PRINTF("Second config option test returns %d", ret);
        }
    }

    if (ret == 0) {
        ret = config_test_parse_command_line_ex(&param2, config_two, (int)(sizeof(config_two) / sizeof(char const*)) - 1);
        if (ret != 0) {
            DBG_PRINTF("Two dash config option test returns %d", ret);
        }
    }

    for (size_t i = 0; ret == 0 && i < nb_config_errors; i++) {
        picoquic_quic_config_t config = { 0 };
        if (config_parse_command_line(&config, config_errors[i].err_args,
            config_errors[i].nb_args, 1) == 0) {
            DBG_PRINTF("Did not detect config error %zu, %s", i, config_errors[i].err_args[0]);
            ret = -1;
        }
    }

    return ret;
}

int config_quic_test_one(picoquic_quic_config_t* config)
{
    int ret = 0;
    picoquic_quic_t * quic;
    uint64_t current_time = 0;

    char const* server_cert_file = NULL;
    char test_server_cert_file[512];
    char const* server_key_file = NULL;
    char test_server_key_file[512];
    char const* root_trust_file = NULL;
    char test_root_trust_file[512];
    char const* root_ech_key_file = NULL;
    char test_ech_key_file[512];
    char const* root_ech_config_file = NULL;
    char test_ech_config_file[512];

    if (ret == 0 && config->server_cert_file != NULL) {
        ret = picoquic_get_input_path(test_server_cert_file, sizeof(test_server_cert_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_SERVER_CERT);
        if (ret == 0) {
            server_cert_file = config->server_cert_file;
            config->server_cert_file = test_server_cert_file;
        }
    }

    if (ret == 0 && config->server_key_file) {
        ret = picoquic_get_input_path(test_server_key_file, sizeof(test_server_key_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_SERVER_KEY);
        if (ret == 0) {
            server_key_file = config->server_key_file;
            config->server_key_file = test_server_key_file;
        }
    }

    if (ret == 0 && config->root_trust_file) {
        ret = picoquic_get_input_path(test_root_trust_file, sizeof(test_root_trust_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_CERT_STORE);
        if (ret == 0) {
            root_trust_file = config->root_trust_file;
            config->root_trust_file = test_root_trust_file;
        }
    }

    if (ret == 0 && config->ech_key_file) {
        ret = picoquic_get_input_path(test_ech_key_file, sizeof(test_ech_key_file), picoquic_solution_dir,
            PICOQUIC_TEST_ECH_PRIVATE_KEY);
        if (ret == 0) {
            root_ech_key_file = config->ech_key_file;
            config->ech_key_file = test_ech_key_file;
        }
    }

    if (ret == 0 && config->ech_config_file) {
        ret = picoquic_get_input_path(test_ech_config_file, sizeof(test_ech_config_file), picoquic_solution_dir,
            PICOQUIC_TEST_ECH_CONFIG);
        if (ret == 0) {
            root_ech_config_file = config->ech_config_file;
            config->ech_config_file = test_ech_config_file;
        }
    }

    quic = picoquic_create_and_configure(config, NULL, NULL, current_time, NULL);
    if (quic == NULL) {
        ret = 1;
    }
    else {
        /* Check that at least some parameters are what we expect */
        if (config->nb_connections > 0 && config->nb_connections != quic->max_number_connections) {
            ret = -1;
        }
        if (config->alpn != NULL &&
            (quic->default_alpn == NULL || strcmp(quic->default_alpn, config->alpn) != 0)) {
            ret = -1;
        }
        if (config->has_reset_seed &&
            memcmp(quic->reset_seed, config->reset_seed, sizeof(config->reset_seed)) != 0) {
            ret = -1;
        }
        if (config->cc_algo_id != NULL &&
            (quic->default_congestion_alg == NULL ||
                strcmp(quic->default_congestion_alg->congestion_algorithm_id, config->cc_algo_id) != 0)) {
            ret = -1;
        }
        if ((config->flow_control_max != 0 &&
            (config->flow_control_max != quic->max_data_limit || config->flow_control_max != quic->default_tp.initial_max_data)) ||
            (config->flow_control_max == 0 &&
            (quic->max_data_limit != 0 || quic->default_tp.initial_max_data != 0x100000))) /* Default value for initial max data tp parameter. */
        {
            ret = -1;
        }
        if ((config->preferred_address_v4 != NULL || config->preferred_address_v6 != NULL) &&
            !quic->default_tp.preferred_address.is_defined) {
            ret = -1;
        }
        picoquic_free(quic);
    }

    if (server_key_file != NULL) {
        config->server_key_file = server_key_file;
    }
    if (server_cert_file != NULL) {
        config->server_cert_file = server_cert_file;
    }
    if (root_trust_file != NULL) {
        config->root_trust_file = root_trust_file;
    }
    if (root_ech_key_file != NULL) {
        config->ech_key_file = root_ech_key_file;
    }
    if (root_ech_config_file != NULL) {
        config->ech_config_file = root_ech_config_file;
    }

    return(ret);
}

int config_quic_test(void)
{
    int ret = 0;
    config_test_register_cc_algorithms();

    if (config_quic_test_one(&param1) != 0 ||
        config_quic_test_one(&param2) != 0) {
        ret = -1;
    }
    return ret;
}

/*
* Testing that the QMux instance is properly created from
* the configuration data */

int config_qmux_parse_test(char const* qmux_string, int expected_port, int expected_nb_connections)
{
    int ret = 0;
    int port = 0xffff;
    int nb_connection = 0xdeadbeef;
    picoqmux_parse_option_string(qmux_string, &port, &nb_connection);

    if (port != expected_port) {
        DBG_PRINTF("Expected QMux port %d, got %d", expected_port, port);
        ret = -1;
    }
    else if (port != -1 && nb_connection != expected_nb_connections) {
        DBG_PRINTF("Expected QMux nb_connections %d, got %d", expected_nb_connections, nb_connection);
        ret = -1;
    }

    return ret;
}

int config_qmux_test_one(picoquic_quic_config_t* config, int qmux_port, int nb_connections)
{
    int ret = 0;
    picoquic_quic_t* qmux;
    uint64_t current_time = 0;
    int qmux_port_used = 0;
    int nb_connections_used = 0;

    char const* server_cert_file = NULL;
    char test_server_cert_file[512];
    char const* server_key_file = NULL;
    char test_server_key_file[512];
    char const* root_trust_file = NULL;
    char test_root_trust_file[512];

    if (ret == 0 && config->server_cert_file != NULL) {
        ret = picoquic_get_input_path(test_server_cert_file, sizeof(test_server_cert_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_SERVER_CERT);
        if (ret == 0) {
            server_cert_file = config->server_cert_file;
            config->server_cert_file = test_server_cert_file;
        }
    }

    if (ret == 0 && config->server_key_file) {
        ret = picoquic_get_input_path(test_server_key_file, sizeof(test_server_key_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_SERVER_KEY);
        if (ret == 0) {
            server_key_file = config->server_key_file;
            config->server_key_file = test_server_key_file;
        }
    }

    if (ret == 0 && config->root_trust_file) {
        ret = picoquic_get_input_path(test_root_trust_file, sizeof(test_root_trust_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_CERT_STORE);
        if (ret == 0) {
            root_trust_file = config->root_trust_file;
            config->root_trust_file = test_root_trust_file;
        }
    }

    qmux = picoqmux_create_and_configure(config, NULL, NULL, current_time, NULL,
        &qmux_port_used, &nb_connections_used);

    if (qmux_port == -1) {
        if (qmux != NULL) {
            ret = -1;
        }
    }
    else if (qmux == NULL) {
        ret = 1;
    }
    else {
        /* Check that at least some parameters are what we expect */
        if (qmux_port_used != qmux_port) {
            ret = -1;
        }
        if (nb_connections!= nb_connections_used) {
            ret = -1;
        }
        if (nb_connections > 0 && nb_connections != (int)qmux->max_number_connections) {
            ret = -1;
        }
        if (config->alpn != NULL &&
            (qmux->default_alpn == NULL || strcmp(qmux->default_alpn, config->alpn) != 0)) {
            ret = -1;
        }
        picoquic_free(qmux);
    }

    if (server_key_file != NULL) {
        config->server_key_file = server_key_file;
    }
    if (server_cert_file != NULL) {
        config->server_cert_file = server_cert_file;
    }
    if (root_trust_file != NULL) {
        config->root_trust_file = root_trust_file;
    }

    return(ret);
}

int config_qmux_test(void)
{
    int ret = 0;

    if (config_qmux_parse_test("443:17", 443, 17) != 0 ||
        config_qmux_parse_test("443", 443, 0) != 0 ||
        config_qmux_parse_test("443:", 443, 0) != 0 ||
        config_qmux_parse_test("443:0", 443, 0) != 0 ||
        config_qmux_parse_test(":17", 0, 17) != 0 ||
        config_qmux_parse_test("0:17", 0, 17) != 0 ||
        config_qmux_parse_test(":", 0, 0) != 0 ||
        config_qmux_parse_test("xyz", -1, 0) != 0 ||
        config_qmux_parse_test("0xyz", -1, 0) != 0 ||
        config_qmux_parse_test("0:xyz", -1, 0) != 0 ||
        config_qmux_parse_test("0:0xyz", -1, 0) != 0) {
        ret = -1;
    }
    else if (config_qmux_test_one(&param1, 443, 17) != 0 ||
        config_qmux_test_one(&param2, -1, 0) != 0) {
        ret = -1;
    }
    return ret;
}

#define CONFIG_USAGE_REF "picoquictest" PICOQUIC_FILE_SEPARATOR "config_usage_ref.txt"
#define CONFIG_USAGE_TXT "config_usage.txt"

int config_usage_test(void)
{

    FILE* F = NULL;
    char config_usage_ref[512];
    int ret = picoquic_get_input_path(config_usage_ref, sizeof(config_usage_ref), picoquic_solution_dir, CONFIG_USAGE_REF);

    config_test_register_cc_algorithms();

    if (ret == 0 && (F = picoquic_file_open(CONFIG_USAGE_TXT, "wt")) != NULL){
        picoquic_config_usage_file(F);
        F = picoquic_file_close(F);
    }

    if (ret == 0) {
        ret = picoquic_test_compare_text_files(CONFIG_USAGE_TXT, config_usage_ref);
    }

    return ret;
}

/* Test the parsing of preferred addresses.
 */

typedef struct st_test_preferred_addr_t {
    char const* test_name;
    char const* v4_text;
    char const* v6_text;
    uint16_t port;
    int is_valid;
    picoquic_tp_preferred_address_t preferred_address;
} test_preferred_addr_t;

#define NULLCID { { 0 }, 0 }

test_preferred_addr_t test_preferred_address_cases[] = {
    {
        "none",
        NULL,
        NULL,
        0,
        1,
        {0}
    },
    {
        "v4_only",
        "192.0.2.1",
        NULL,
        4433,
        1,
        {
            1,
            { 192, 0, 2, 1 },
            4433,
            { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            0,
            NULLCID,
            { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
        }
    },
    {
        "v6_only",
        NULL,
        "2001:db8::1",
        4433,
        1,
        {
            1,
            { 0, 0, 0, 0 },
            0,
            { 0x20,  0x01, 0x0d, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
            4433,
            NULLCID,
            { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
        }
    },
    {
        "both",
        "192.0.2.1",
        "2001:db8::1",
        4433,
        1,
        {
            1,
            { 192, 0, 2, 1 },
            4433,
            { 0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
            4433,
            NULLCID,
            { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
        }
    },
    {
        "bad v4",
        "192.a.b.c",
        "2001:db8::1",
        4433,
        0,
        { 0}
    },
    {
        "bad v6",
        "192.0.2.1",
        "2001:local",
        4433,
        0,
        { 0 }
    }
};

int config_preferred_test(void)
{
    int ret = 0;
    for (size_t i = 0; ret == 0 && i < sizeof(test_preferred_address_cases) / sizeof(test_preferred_addr_t); i++) {
        picoquic_tp_preferred_address_t preferred_address;
        memset(&preferred_address, 0, sizeof(preferred_address));
        int is_valid = (picoquic_set_preferred_address(&preferred_address, test_preferred_address_cases[i].v4_text,
            test_preferred_address_cases[i].v6_text, test_preferred_address_cases[i].port) == 0);
        if (is_valid != test_preferred_address_cases[i].is_valid) {
            DBG_PRINTF("Test case %s: expected validity %d, got %d", test_preferred_address_cases[i].test_name,
                test_preferred_address_cases[i].is_valid, is_valid);
            ret = -1;
        }
        else if (is_valid) {
            if (preferred_address.is_defined != test_preferred_address_cases[i].preferred_address.is_defined ||
                memcmp(test_preferred_address_cases[i].preferred_address.ipv4Address, preferred_address.ipv4Address, 4) != 0 ||
                test_preferred_address_cases[i].preferred_address.ipv4Port != preferred_address.ipv4Port ||
                memcmp(test_preferred_address_cases[i].preferred_address.ipv6Address, preferred_address.ipv6Address, 16) != 0 ||
                test_preferred_address_cases[i].preferred_address.ipv6Port != preferred_address.ipv6Port) {
                DBG_PRINTF("Test case %s: expected and actual preferred addresses differ", test_preferred_address_cases[i].test_name);
                ret = -1;
            }
        }
    }
    return ret;
}

/*
* test of the port setting option.
*/

int config_set_port(picoquic_quic_config_t* config, char const* port_string);


typedef struct st_test_set_port_t {
    char const* port_string;
    int is_valid;
    uint16_t server_port;
    uint16_t local_port;
    uint16_t nb_threads;
    int is_port_shared;
} test_set_port_t;

test_set_port_t test_set_port_cases[] = {
    { "4433", 1, 4433, 0, 0, 0 },
    { "443:4434", 1, 443, 4434, 0, 0 },
    { "S4433", 1, 4433, 0, 0, 1 },
    { "S443:4434", 1, 443, 4434, 0, 1 },
    { "S443:4434*", 1, 443, 4434, 0, 1 },
    { "S443:4434*1", 1, 443, 4434, 1, 1 },
    { "S443:4434*256", 1, 443, 4434, 256, 1 },
    { "4433*7", 1, 4433, 0, 7, 0 },
    { "", 1, 0, 0, 0, 0 },
    { "0", 1, 0, 0, 0, 0 },
    { "*5", 1, 0, 0, 5, 0 },
    { "0*3", 1, 0, 0, 3, 0 },
    { "65535", 1, 65535, 0, 0, 0 },
    { "S65535", 1, 65535, 0, 0, 1 },
    { "S65534:65535", 1, 65534, 65535, 0, 1 },
    { "65536", 0, 0, 0, 0, 0 },
    { "-1", 0, 0, 0, 0, 0 },
    { "abc", 0, 0, 0, 0, 0 },
    { "4433:abc", 0, 0, 0, 0, 0 },
    { "abc:4433", 0, 0, 0, 0, 0 },
    { "S4433:abc", 0, 0, 0, 0, 0 },
    { "Sabc:4433", 0, 0, 0, 0, 0 },
};

int config_set_port_test(void)
{
    int ret = 0;
    for (size_t i = 0; ret == 0 && i < sizeof(test_set_port_cases) / sizeof(test_set_port_t); i++) {
        picoquic_quic_config_t config = { 0 };
        int is_valid = (config_set_port(&config, test_set_port_cases[i].port_string) == 0);
        if (is_valid != test_set_port_cases[i].is_valid) {
            DBG_PRINTF("Test case %zu: expected validity %d, got %d", i, test_set_port_cases[i].is_valid, is_valid);
            ret = -1;
        }
        else if (is_valid) {
            if (config.server_port != test_set_port_cases[i].server_port ||
                config.local_port != test_set_port_cases[i].local_port ||
                config.is_port_shared != test_set_port_cases[i].is_port_shared) {
                DBG_PRINTF("Test case %zu: expected and actual port settings differ", i);
                ret = -1;
            }
        }
    }
    return ret;
}
